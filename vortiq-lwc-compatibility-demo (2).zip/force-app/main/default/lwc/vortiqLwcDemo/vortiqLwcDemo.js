import { LightningElement, track } from 'lwc';
import searchAccounts from '@salesforce/apex/VortiQLCompatibilityController.searchAccounts';

export default class VortiqLwcDemo extends LightningElement {
    @track accounts;
    searchTerm = '';
    errorMessage = '';

    handleSearchChange(event) {
        this.searchTerm = event.target.value;
    }

    async handleSearch() {
        this.errorMessage = '';
        this.accounts = undefined;

        try {
            this.accounts = await searchAccounts({
                searchTerm: this.searchTerm
            });
        } catch (error) {
            this.errorMessage =
                error?.body?.message || 'Unable to retrieve Salesforce data.';
        }
    }
}
