# VortiQL – Salesforce LWC Compatibility Demonstration

> **Important:** This is an independently created Salesforce Lightning Web Component (LWC) demonstration repository. It is **not an official VortiQL repository, vendor plug-in, Salesforce AppExchange package, or VortiQL source-code distribution**.

## Purpose

This project demonstrates a reusable Salesforce LWC integration pattern that can be used to evaluate compatibility with a client's Lightning Web Component framework.

The demonstration covers:

- Lightning Web Components (LWC)
- Apex controller integration
- REST-style service abstraction
- SOQL-based Salesforce data access
- Lightning Data Service patterns
- SLDS-compatible UI
- Error handling
- Configurable service endpoints
- Salesforce DX project structure
- Git/GitHub version control workflow

## Compatibility Notes

The component is intentionally implemented using standard Salesforce LWC patterns and does not depend on undocumented Salesforce framework APIs.

Compatibility areas to review during a client technical evaluation:

1. Salesforce API version
2. Lightning Web Security / supported JavaScript behavior
3. SLDS version and styling requirements
4. Apex sharing and CRUD/FLS enforcement
5. Named Credentials for external endpoints
6. CSP Trusted Sites where applicable
7. Salesforce governor limits
8. Client-side event and component communication patterns

## Repository Status

This repository is a technical demonstration prepared for compatibility discussion. It should not be represented as an official VortiQL repository unless an authorized VortiQL vendor/developer provides the official source or documentation.

## Deployment

```bash
sf org login web --alias myorg
sf project deploy start --source-dir force-app
```

Then open the Salesforce App Launcher and add the `VortiQL LWC Demo` component to a Lightning record/home page.

## Author

Salesforce Developer demonstration project.
