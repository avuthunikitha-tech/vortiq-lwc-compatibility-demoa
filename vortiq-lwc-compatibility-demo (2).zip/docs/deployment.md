# Deployment

## Prerequisites

- Salesforce CLI (`sf`)
- Salesforce org
- Appropriate deployment permissions

## Login

```bash
sf org login web --alias myorg
```

## Deploy

```bash
sf project deploy start --source-dir force-app --target-org myorg
```

## Verify

Open a Lightning App, Home Page, or Record Page and add:

`VortiQL LWC Demo`

The component provides a simple Salesforce Account search to demonstrate LWC-to-Apex communication.
