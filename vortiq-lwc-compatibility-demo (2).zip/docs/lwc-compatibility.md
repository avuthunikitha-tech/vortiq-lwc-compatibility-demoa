# LWC Compatibility Checklist

## Framework

- Standard Lightning Web Components
- JavaScript ES modules
- Salesforce Lightning Base Components
- SLDS-compatible markup
- Apex `@AuraEnabled` integration

## Security

The demonstration uses an Apex class declared `with sharing`.

For production use, the implementation should additionally enforce object-level and field-level security appropriate to the client's Salesforce org.

## External Integrations

If VortiQL requires an external service, the recommended Salesforce pattern is:

LWC → Apex → Named Credential → External Service/API

Avoid hard-coded credentials or endpoint secrets in JavaScript.

## Client Validation

Before production deployment, validate the client's:

- Salesforce API version
- Lightning Web Security configuration
- managed-package dependencies
- namespace requirements
- CSP configuration
- authentication model
- Apex sharing/security requirements
