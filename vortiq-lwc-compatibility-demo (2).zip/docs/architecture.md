# Architecture

```text
Lightning Page
     |
     v
VortiQL LWC Demo
     |
     | @salesforce/apex
     v
VortiQLCompatibilityController
     |
     | SOQL
     v
Salesforce Account
```

For a real external VortiQL implementation, the integration boundary can be extended to:

```text
LWC
 |
 v
Apex Service Layer
 |
 v
Named Credential
 |
 v
Authorized External VortiQL API
```

This repository intentionally does not claim that this architecture is the official VortiQL implementation.
